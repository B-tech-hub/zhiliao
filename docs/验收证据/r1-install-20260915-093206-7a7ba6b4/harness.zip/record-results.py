import difflib
import json
import re
from collections import Counter
from datetime import datetime
from r1lib import ROOT, RUN, REPO, now, save, sha


def read(name):
    return json.loads((ROOT / "evidence" / name).read_text(encoding="utf-8"))


build = read("build.json")
browser = read("browser-report.json")
before_data = read("data-before-restart.json")
after_data = read("data-after-restart.json")
without_data = read("data-without-model.json")
assert build["status"] == "passed"
assert all(d["passed"] for d in (before_data, after_data, without_data))
assert browser.get("finishedUtc")
manifest = read("source-manifest.json")
assert all(sha(ROOT / "source" / path) == value for path, value in manifest.items())

initial_override = (ROOT / "evidence" / "compose-initial.txt").read_text(encoding="utf-8")
final_override = (ROOT / "compose.r1.yml").read_text(encoding="utf-8")
diff = "".join(difflib.unified_diff(initial_override.splitlines(True), final_override.splitlines(True), fromfile="approved/compose.r1.yml", tofile="executed/compose.r1.yml"))
(ROOT / "evidence" / "compose-runtime-change.txt").write_text(diff, encoding="utf-8", newline="\n")

old_report_path = REPO / "docs/验收证据/story-2-2-runtime-b2-2026-09-12T11-48-30Z-network.json"
old_report = json.loads(old_report_path.read_text(encoding="utf-8"))
old_net = [n for n in old_report["networks_before"] if n["name"] == "zhiliao-demo-verify-49c029e613bd-ingress"][0]
assert old_net["internal"] is False
save(ROOT / "evidence" / "ingress-config-finding.json", {
    "runId": RUN["runId"], "timeUtc": now(),
    "originalResult": "三个容器健康，但实际宿主端口映射为空，回环请求被拒绝",
    "approvedTemplateIngressInternal": True,
    "oldB2IngressInternal": False, "oldB2NetworkReportSha256": sha(old_report_path),
    "executedTemporaryOverride": {"networks.ingress_net.internal": False},
    "businessNetworkRemainsInternalIsolated": True,
    "repositoryComposeModified": False, "candidateRebuilt": False,
    "originalFailureEvidence": ["runtime-start-failure.json", "host-probe-diagnosis.json", "runtime-network-diagnosis.json"],
    "correctionEvidence": ["compose-runtime-change.txt", "config-redacted.json", "initial-runtime.json", "runtime-business-isolation.json"],
    "remaining": "仓库默认 Compose 仍保留 internal:true；本轮通过只适用于记录的临时入口修正",
})

state = json.loads((ROOT / "private" / "resources-before-cleanup.json").read_text(encoding="utf-8"))
save(ROOT / "evidence" / "runtime-final-bindings.json", {
    "runId": RUN["runId"], "timeUtc": now(),
    "containers": [{
        "id": c["Id"], "service": c["Config"]["Labels"]["com.docker.compose.service"],
        "imageId": c["Image"], "requestedPorts": c["HostConfig"]["PortBindings"],
        "actualPorts": c["NetworkSettings"]["Ports"], "networks": list(c["NetworkSettings"]["Networks"]),
        "health": c["State"]["Health"]["Status"],
    } for c in state["container"]],
})

build_log = (ROOT / "evidence" / "build.log").read_text(encoding="utf-8")
save(ROOT / "evidence" / "build-diagnosis.json", {
    "runId": RUN["runId"], "timeUtc": now(), "buildAttempts": 1,
    "observedBottleneck": "npm ci 下载并解压 @next/swc-linux-x64-musl@15.5.23 较慢；文件与网络字节持续增长",
    "hypotheses": [
        {"name": "依赖下载等待", "result": "支持：npm 日志、打开的下载文件、TCP 连接与连续文件增长吻合"},
        {"name": "原生编译耗时", "result": "采样期未支持：仅 npm ci，无编译子进程"},
        {"name": "资源或输出停滞", "result": "未发现 OOM；文件持续增长，不能仅凭控制台静默判定停滞"},
    ],
    "npmCiSeconds": 1704.8, "nextBuildSeconds": 45.6,
    "dependenciesChanged": False, "proxyOrSystemConfigurationChanged": False,
    "npmLogScope": "npm-ci-debug.log 为运行中采集的部分日志；最终退出与完整构建输出见 build.log",
    "npmAutomaticAudit": {"total": 37, "moderate": 34, "high": 2, "critical": 1, "triaged": False},
    "buildWarnings": ["libheif-js 动态 require", "package.json 的 version 命名导入", "jose 在 Edge Runtime 引用 CompressionStream/DecompressionStream"],
    "proxyWarningScope": "WSL 提示 localhost 代理未映射，但本轮没有证明它是下载缓慢的根因",
})

steps = browser["steps"]
statuses = Counter(str(x["status"]) for x in browser["network"])
startup = read("startup-config-up.json")
first_saved = datetime.fromisoformat(steps["first-note"]["savedUtc"].replace("Z", "+00:00"))
ready_at = datetime.fromisoformat(startup["finishedUtc"])
summary = {
    "runId": RUN["runId"], "timeUtc": now(),
    "status": "completed-with-findings",
    "conclusion": "按临时入口修正完成 Windows Docker Desktop 本机安装主流程；原模板入口与浏览器异常仍须处理，R1 整体未关闭",
    "singleAgent": True, "models": "仅本机 mock", "imageId": RUN["imageId"], "imageTag": RUN["imageTag"],
    "baseCommit": RUN["baseCommit"], "workingTree": True, "platform": "linux/amd64",
    "sourceFiles": len(manifest), "sourceFilesUnchanged": True, "sourceManifestSha256": build["sourceManifestSha256"],
    "checks": {
        "build": True, "originalTemplateIngress": False, "temporaryCorrectedIngress": True,
        "emptyDatabaseAndVersion": True, "realBrowserLogin": True, "saveWithoutModel": True,
        "keywordSearchAndReopen": True, "markdownAndZip": True, "mockProcessingAndBodyPreservation": True,
        "recreationPersistence": True, "browserWithoutErrors": False,
    },
    "timingSeconds": {
        "build": build["elapsedSeconds"], "npmCi": 1704.8, "nextBuild": 45.6,
        "initialUp": read("startup.json")["elapsedSeconds"],
        "correctedUp": startup["elapsedSeconds"],
        "loginToFirstSave": steps["first-note"]["secondsFromLogin"],
        "correctedHealthyToFirstSave": round((first_saved - ready_at).total_seconds(), 3),
        "restartDown": read("restart-down.json")["elapsedSeconds"], "restartUp": read("restart-up.json")["elapsedSeconds"],
    },
    "notes": [{"id": n["id"], "aiStatus": n["ai_status"], "title": n["title"], "bodyMatches": True} for n in after_data["db"]["notes"]],
    "exports": [without_data["zip"], after_data["zip"]],
    "browser": {"version": browser["browserVersion"], "httpStatusCounts": dict(statuses), "pageErrors": [e for e in browser["errors"] if e["kind"] == "pageerror"], "blockedExternalRequests": len(browser["blocked"]), "cookieInjected": False, "serviceWorkerBlockedByHarness": True},
    "limitations": [
        "原 Compose 的入口内网标记尚未修复；本轮仅更改临时覆盖，不能宣称原模板直接启动通过",
        "静态资源共六次 503，日志匹配 Nginx 限流；首轮导致 ChunkLoadError 和一次操作超时，刷新后恢复",
        "设置页刷新出现一次 React #418，具体不一致字段未定位",
        "浏览器路由拦截会关闭 HTTP 缓存，故本次 503 不能直接推定普通缓存浏览器的发生率",
        "npm ci 自带审计报告 37 项，含 1 critical 和 2 high；未做依赖漏洞分诊或修复",
        "已有构建缓存命中，不是无缓存分发获取；本地 image ID 不是 GHCR 发布摘要",
        "未覆盖独立 Linux、ARM64、R2 恢复、来源问答/模型失败全矩阵、真实模型效果、完整门禁或发布",
    ],
    "cleanup": read("cleanup-runtime.json"),
    "visualReview": {"singleAgent": True, "files": ["02-note-without-model.png", "04-mock-note.png"], "bodyAndMetadataVisible": True},
}
save(ROOT / "evidence" / "summary.json", summary)
save(ROOT / "evidence" / "browser-driver-adjustment.json", {
    "runId": RUN["runId"], "timeUtc": now(),
    "initialDriver": "隐藏启动的浏览器驱动未收到标准输入，未打开应用或创建笔记",
    "action": "确认驱动命令行与父进程后关闭该进程树，改用显式标准输入/输出管道启动独立浏览器",
    "initialDriverPid": 26460, "actualDriverPid": browser["driverPid"],
    "actualBrowserClosed": True, "productCodeChanged": False,
})
print(json.dumps({"status": summary["status"], "timingSeconds": summary["timingSeconds"], "httpStatusCounts": dict(statuses), "sourceFilesUnchanged": True}, ensure_ascii=False))
