import json
import secrets
import shutil
import socket
import zipfile
from pathlib import Path
from r1lib import ROOT, RUN, REPO, command, docker, git, git_files, now, save, sha, resources, preservation

started = now()
(ROOT / "private").mkdir(exist_ok=True)
(ROOT / "evidence").mkdir(exist_ok=True)
if git("rev-parse", "HEAD").strip() != RUN["baseCommit"]:
    raise RuntimeError("HEAD 与批准方案不同。")
if json.loads((REPO / "package.json").read_text(encoding="utf-8"))["version"] != "0.6.1":
    raise RuntimeError("包版本不符。")
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
    probe.bind(("127.0.0.1", RUN["port"]))

old = json.loads((REPO / "docs/验收证据/r1-source-demo-20260914T070442Z-5c531772/candidate-manifest.json").read_text(encoding="utf-8"))
different = [p for p, h in old.items() if not (REPO / p).is_file() or sha(REPO / p) != h]
if different:
    save(ROOT / "evidence" / "source-drift.json", different)
    raise RuntimeError("已审阅源码发生变化，详见 source-drift.json。")
before = preservation()
save(ROOT / "private" / "preservation-before.json", before)
inventory = resources()
if any(RUN["project"] in x["name"] for x in inventory["containers"]):
    raise RuntimeError("本轮 project 已有容器。")
if any(RUN["project"] in x["Name"] for x in inventory["volumes"]):
    raise RuntimeError("本轮 project 已有卷。")
if any(RUN["project"] in x["Name"] for x in inventory["networks"]):
    raise RuntimeError("本轮 project 已有网络。")
save(ROOT / "private" / "resources-before.json", inventory)
version = json.loads(docker("version", "--format", "{{json .}}"))
save(ROOT / "evidence" / "docker-version.json", version)
info = json.loads(docker("info", "--format", '{"cpus":{{.NCPU}},"memoryBytes":{{.MemTotal}},"driver":{{json .Driver}},"os":{{json .OSType}},"architecture":{{json .Architecture}}}'))
nginx_ref = "nginx:1.30.4-alpine@sha256:dc5069ad14f19660b141b21236140b91656bf89bbc3e2417c70ae650cd66104c"
nginx = json.loads(docker("image", "inspect", nginx_ref))[0]
save(ROOT / "evidence" / "nginx-image.json", {
    "reference": nginx_ref, "id": nginx["Id"],
    "repoDigests": nginx["RepoDigests"], "os": nginx["Os"], "architecture": nginx["Architecture"],
})

source = ROOT / "source"
if source.exists():
    raise RuntimeError("源码副本已存在。")
source.mkdir()
paths = git_files("src", "public", "scripts", "tests")
roots = [
    ".dockerignore", ".gitattributes", ".gitignore", "Dockerfile", "LICENSE",
    "package.json", "package-lock.json", "next.config.ts", "next-env.d.ts",
    "tsconfig.json", "postcss.config.mjs", "eslint.config.mjs", "vitest.config.mts",
]
paths = sorted(set(paths + roots))
manifest = {}
for relative in paths:
    p = REPO / relative
    if not p.is_file() or p.is_symlink():
        raise RuntimeError(f"输入文件不存在或是链接：{relative}")
    if any(part.startswith(".env") or part in (".git", "node_modules") for part in Path(relative).parts):
        raise RuntimeError("构建清单包含禁止输入。")
    if p.resolve().is_relative_to(REPO.resolve()) is False:
        raise RuntimeError("构建输入越界。")
    h = sha(p)
    target = source / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(p, target)
    if sha(target) != h or sha(p) != h:
        raise RuntimeError(f"复制期间输入变化：{relative}")
    manifest[relative] = h
save(ROOT / "source-manifest.json", manifest)
shutil.copy2(ROOT / "source-manifest.json", ROOT / "evidence" / "source-manifest.json")
with zipfile.ZipFile(ROOT / "evidence" / "source-snapshot.zip", "w", compression=zipfile.ZIP_DEFLATED) as z:
    for relative in paths:
        z.write(source / relative, relative)

shutil.copy2(REPO / "docker-compose.demo.yml", ROOT / "compose.base.yml")
(ROOT / "nginx").mkdir()
shutil.copy2(REPO / "nginx" / "demo.conf", ROOT / "nginx" / "demo.conf")
plan = (REPO / "docs/R1安装验收准备-2026-09-14.md").read_text(encoding="utf-8")
fence = chr(96) * 3
overlay = plan.split(fence + "yaml\n", 1)[1].split(fence, 1)[0]
(ROOT / "compose.r1.yml").write_text(overlay, encoding="utf-8", newline="\n")
(ROOT / "notes").mkdir()
credentials = {"password": secrets.token_hex(16), "sessionSecret": secrets.token_hex(32), "mockKey": "[REDACTED_mockKey]"}
save(ROOT / "private" / "credentials.json", credentials)

profile = Path(r"C:\Program Files\Google\Chrome\Application\chrome.exe")
playwright = Path(r"C:\Users\BAIBAI\AppData\Local\npm-cache\_npx\9833c18b2d85bc59\node_modules\playwright")
if not profile.is_file() or not (playwright / "package.json").is_file():
    raise RuntimeError("已安装的浏览器或 Playwright 不可用。")
summary = {
    "runId": RUN["runId"], "startedUtc": started, "finishedUtc": now(),
    "baseCommit": RUN["baseCommit"], "version": "0.6.1", "workingTree": True,
    "sourceFiles": len(manifest), "sourceManifestSha256": sha(ROOT / "source-manifest.json"),
    "sourceArchiveSha256": sha(ROOT / "evidence" / "source-snapshot.zip"),
    "previousRuntimeFingerprintsMatched": len(old),
    "copiedOriginalEnvOrData": False, "copiedDependenciesOrBuildOutput": False,
    "dockerInfo": info, "composeVersion": docker("compose", "version").strip(),
    "originalContainerCount": len(inventory["containers"]),
    "originalVolumeCount": len(inventory["volumes"]),
    "originalNetworkCount": len(inventory["networks"]),
    "workspaceFilesProtected": len(before["workspace"]),
    "protectedFileHashes": len(before["protected"]),
    "dataMetadataFiles": len(before["dataMetadata"]),
    "port": RUN["port"], "portFree": True,
    "browserAlreadyInstalled": True, "playwrightAlreadyInstalled": True,
    "hostTempDiskFreeBytes": shutil.disk_usage(ROOT).free,
    "repositoryDiskFreeBytes": shutil.disk_usage(REPO).free,
    "configSha256": {
        "base": sha(ROOT / "compose.base.yml"),
        "override": sha(ROOT / "compose.r1.yml"),
        "nginx": sha(ROOT / "nginx" / "demo.conf"),
        "approvedPlan": sha(REPO / "docs/R1安装验收准备-2026-09-14.md"),
    },
}
save(ROOT / "evidence" / "preparation.json", summary)
print(json.dumps(summary, ensure_ascii=False))
