import json
import re
import sys
import zipfile
from r1lib import ROOT, RUN, docker, now, save, sha

phase = sys.argv[1]
browser = json.loads((ROOT / "evidence" / "browser-report.json").read_text(encoding="utf-8"))
targets = [browser["steps"][key] for key in ("first-note", "mock-note") if key in browser["steps"]]
assert targets
ids = docker("ps", "-q", "--filter", "label=com.docker.compose.project=" + RUN["project"], "--filter", "label=com.docker.compose.service=app").split()
assert len(ids) == 1
app = json.loads(docker("container", "inspect", ids[0]))[0]
assert app["Config"]["Labels"]["io.zhiliao.r1.run"] == RUN["runId"]
assert app["Image"] == RUN["imageId"]
mounts = {m["Destination"]: m for m in app["Mounts"]}
assert mounts["/data/db"]["Name"] == RUN["project"] + "_install_db"
assert mounts["/data/uploads"]["Name"] == RUN["project"] + "_install_uploads"
db_code = r"""const db=new (require('better-sqlite3'))(process.env.DATABASE_PATH,{readonly:true,fileMustExist:true});const notes=db.prepare('select id,title,content,topic_id,ai_status from notes where deleted_at is null order by id').all();for(const n of notes)n.tags=db.prepare('select t.name from tags t join note_tags nt on nt.tag_id=t.id where nt.note_id=? order by t.name').all(n.id).map(x=>x.name);const topics=db.prepare('select id,name,is_system from topics order by id').all();const models=db.prepare("select key,value from settings where key like 'llm_%' or key like 'vision_%' or key like 'image_%' or key like 'reasoning_%' or key like 'embedding_%' order by key").all().map(x=>({...x,value:x.key.endsWith('api_key')?(x.value?'[已配置]':''):x.value}));db.close();process.stdout.write(JSON.stringify({notes,topics,models}));"""
db = json.loads(docker("exec", ids[0], "node", "-e", db_code))
by_id = {n["id"]: n for n in db["notes"]}

def body(text):
    normalized = text.replace("\r\n", "\n")
    if normalized.startswith("---\n"):
        normalized = normalized.split("\n---\n", 1)[1].lstrip("\n")
    return normalized.rstrip("\n")

markdown = []
for target in targets:
    note = by_id[target["id"]]
    assert note["content"] == target["input"]
    files = [p for p in (ROOT / "notes").rglob("*.md") if target["id"] in p.name]
    assert len(files) == 1
    assert body(files[0].read_text(encoding="utf-8")) == target["input"]
    markdown.append({"noteId": target["id"], "path": files[0].relative_to(ROOT / "notes").as_posix(), "sha256": sha(files[0]), "bodyMatches": True})
if phase == "without-model":
    assert all(n["ai_status"] != "done" for n in db["notes"])
    assert not any(m["value"] for m in db["models"] if m["key"] in ("llm_base_url", "llm_model", "llm_api_key"))
else:
    model_map = {m["key"]: m["value"] for m in db["models"]}
    assert model_map["llm_base_url"] == "http://mockllm:8787/v1"
    assert model_map["llm_model"] == "mock"
    for key in ("vision_model", "image_model", "reasoning_model", "embedding_model"):
        assert not model_map.get(key)
    mocked = by_id[browser["steps"]["mock-note"]["id"]]
    assert mocked["ai_status"] == "done"
    assert {"羽毛球", "训练"}.issubset(mocked["tags"])
    topic_names = {t["id"]: t["name"] for t in db["topics"]}
    assert topic_names[mocked["topic_id"]] == "羽毛球"

zip_name = "export-without-model.zip" if phase == "without-model" else ("export-after-restart.zip" if phase == "after-restart" else None)
zip_check = None
if zip_name:
    path = ROOT / "evidence" / zip_name
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        matched = []
        for target in targets:
            entries = [i for i in z.infolist() if i.filename.endswith(".md") and target["id"] in i.filename]
            assert len(entries) == 1
            assert body(z.read(entries[0]).decode("utf-8")) == target["input"]
            matched.append({"noteId": target["id"], "entry": entries[0].filename, "bodyMatches": True})
        zip_check = {"file": zip_name, "sha256": sha(path), "bytes": path.stat().st_size, "crcPassed": True, "notes": matched}

marker_name = "r1-persistence-" + RUN["runId"] + ".txt"
marker_value = "r1-install:" + RUN["runId"]
marker = None
if phase == "before-restart":
    code = "const fs=require('fs');const p='/data/uploads/'+process.argv[1];const value=process.argv[2];if(fs.existsSync(p)){if(fs.readFileSync(p,'utf8')!==value)throw Error('标记冲突')}else fs.writeFileSync(p,value,{flag:'wx'});process.stdout.write(JSON.stringify({name:process.argv[1],bodyMatches:fs.readFileSync(p,'utf8')===value}));"
    marker = json.loads(docker("exec", ids[0], "node", "-e", code, marker_name, marker_value))
elif phase == "after-restart":
    code = "const fs=require('fs');const p='/data/uploads/'+process.argv[1];process.stdout.write(JSON.stringify({name:process.argv[1],bodyMatches:fs.readFileSync(p,'utf8')===process.argv[2]}));"
    marker = json.loads(docker("exec", ids[0], "node", "-e", code, marker_name, marker_value))
    assert marker["bodyMatches"]
    before = json.loads((ROOT / "evidence" / "data-before-restart.json").read_text(encoding="utf-8"))
    before_notes = {n["id"]: n for n in before["db"]["notes"]}
    assert set(before_notes) == set(by_id)
    for key, expected in before_notes.items():
        assert expected["content"] == by_id[key]["content"]
        if expected["ai_status"] == "done":
            for field in ("title", "topic_id", "tags", "ai_status"):
                assert expected[field] == by_id[key][field]

report = {
    "runId": RUN["runId"], "phase": phase, "timeUtc": now(), "db": db,
    "markdown": markdown, "zip": zip_check, "uploadMarker": marker,
    "passed": True, "scope": "本轮合成笔记、Markdown、ZIP 下载及挂载持久化；不是导回或完整恢复",
}
save(ROOT / "evidence" / ("data-" + phase + ".json"), report)
print(json.dumps({"phase": phase, "notes": len(db["notes"]), "markdown": len(markdown), "zipChecked": bool(zip_check), "uploadMarkerChecked": bool(marker), "passed": True}, ensure_ascii=False))
