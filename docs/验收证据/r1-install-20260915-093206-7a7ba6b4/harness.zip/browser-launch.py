import subprocess
import sys
import threading
from r1lib import ROOT, HIDDEN, clean_env

process = subprocess.Popen(
    [r"D:\node.js\node.exe", str(ROOT / "browser-driver.cjs")],
    cwd=ROOT, env=clean_env(), creationflags=HIDDEN,
    stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
)

def read_output():
    for line in iter(process.stdout.readline, b""):
        sys.stdout.write(line.decode("utf-8", errors="replace"))
        sys.stdout.flush()

reader = threading.Thread(target=read_output, daemon=True)
reader.start()
for line in sys.stdin:
    process.stdin.write(line.encode("utf-8"))
    process.stdin.flush()
    if '"close"' in line:
        break
process.stdin.close()
code = process.wait()
reader.join(timeout=5)
sys.exit(code)
