$ErrorActionPreference = 'Stop'
$r1RunId = '20260915-093206-7a7ba6b4'
$r1ExpectedLeaf = 'zhiliao-r1-install-061-' + $r1RunId
$r1Target = [IO.Path]::GetFullPath('C:\Users\BAIBAI\AppData\Local\Temp\zhiliao-r1-install-061-20260915-093206-7a7ba6b4')
$r1TempParent = (Resolve-Path -LiteralPath ([IO.Path]::GetTempPath())).Path.TrimEnd('\')
if ([IO.Path]::GetDirectoryName($r1Target) -ine $r1TempParent -or [IO.Path]::GetFileName($r1Target) -ne $r1ExpectedLeaf) {
    throw '本轮清理目标不在指定 TEMP 目录。'
}
$r1ResolvedTarget = (Resolve-Path -LiteralPath $r1Target).Path
if ($r1ResolvedTarget -ine $r1Target) { throw '清理目标解析不符。' }
$r1Run = Get-Content -Raw -Encoding UTF8 -LiteralPath (Join-Path $r1Target 'run.json') | ConvertFrom-Json
if ($r1Run.runId -ne $r1RunId -or $r1Run.root -ine $r1Target -or $r1Run.repository -ine 'D:\ClaudeProjects\ai_acknowladge') {
    throw '运行标记不符。'
}
$r1Items = @(Get-Item -Force -LiteralPath $r1Target) + @(Get-ChildItem -Force -Recurse -LiteralPath $r1Target)
if (@($r1Items | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint }).Count -gt 0) {
    throw '目录中有重解析点，停止自动删除。'
}
$r1Processes = @(Get-CimInstance Win32_Process | Where-Object {
    $_.Name -in @('node.exe', 'chrome.exe', 'python.exe') -and $_.CommandLine -like ('*' + $r1ExpectedLeaf + '*')
})
if ($r1Processes.Count -gt 0) { throw '本轮目录仍有关联进程。' }
$r1Docker = 'C:\Program Files\Docker\Docker\resources\bin\docker.exe'
$r1Filter = 'label=com.docker.compose.project=' + $r1Run.project
$r1RemainingContainers = @(& $r1Docker --context desktop-linux ps -aq --filter $r1Filter)
if ($LASTEXITCODE -ne 0) { throw '容器检查失败。' }
$r1RemainingVolumes = @(& $r1Docker --context desktop-linux volume ls -q --filter $r1Filter)
if ($LASTEXITCODE -ne 0) { throw '卷检查失败。' }
$r1RemainingNetworks = @(& $r1Docker --context desktop-linux network ls -q --filter $r1Filter)
if ($LASTEXITCODE -ne 0) { throw '网络检查失败。' }
if (($r1RemainingContainers.Count + $r1RemainingVolumes.Count + $r1RemainingNetworks.Count) -ne 0) {
    throw '本轮 Docker 资源尚未全部清理。'
}
$r1RetainedImage = & $r1Docker --context desktop-linux image inspect --format '{{.Id}}' $r1Run.imageId
if ($LASTEXITCODE -ne 0 -or $r1RetainedImage.Trim() -ne $r1Run.imageId) { throw '候选镜像保留核对失败。' }
$r1Listener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback, [int]$r1Run.port)
try { $r1Listener.Start() } finally { $r1Listener.Stop() }

$r1Archive = [IO.Path]::GetFullPath('D:\ClaudeProjects\ai_acknowladge\docs\验收证据\r1-install-' + $r1RunId)
$r1ManifestPath = Join-Path $r1Archive 'artifact-manifest.json'
$r1Manifest = Get-Content -Raw -Encoding UTF8 -LiteralPath $r1ManifestPath | ConvertFrom-Json
if ($r1Manifest.runId -ne $r1RunId -or -not $r1Manifest.credentialScanPassed) { throw '证据清单或脱敏检查不符。' }
foreach ($r1Entry in $r1Manifest.files) {
    $r1ArchivedFile = [IO.Path]::GetFullPath((Join-Path $r1Archive $r1Entry.path))
    if ([IO.Path]::GetDirectoryName($r1ArchivedFile) -ine $r1Archive) { throw '证据路径越界。' }
    $r1Hash = (Get-FileHash -Algorithm SHA256 -LiteralPath $r1ArchivedFile).Hash.ToLowerInvariant()
    if ($r1Hash -ne $r1Entry.sha256) { throw '归档证据哈希不符。' }
    $r1TemporaryFile = Join-Path (Join-Path $r1Target 'evidence') $r1Entry.path
    if ((Get-FileHash -Algorithm SHA256 -LiteralPath $r1TemporaryFile).Hash.ToLowerInvariant() -ne $r1Hash) {
        throw '临时证据与归档副本不同。'
    }
}
$r1FinalAudit = Get-Content -Raw -Encoding UTF8 -LiteralPath (Join-Path $r1Archive 'preservation-final.json') | ConvertFrom-Json
if (-not $r1FinalAudit.passed) { throw '最终保护检查尚未通过。' }

Remove-Item -LiteralPath $r1Target -Recurse -Force
if (Test-Path -LiteralPath $r1Target) { throw '临时目录仍存在。' }
$r1Cleanup = [ordered]@{
    runId = $r1RunId
    timeUtc = (Get-Date).ToUniversalTime().ToString('o')
    temporaryDirectory = '%TEMP%/' + $r1ExpectedLeaf
    temporaryDirectoryRemoved = $true
    resolvedTargetAndTempParentChecked = $true
    reparsePoints = 0
    relatedProcesses = 0
    archiveFilesVerifiedBeforeRemoval = @($r1Manifest.files).Count
    remainingDockerResources = 0
    portReleased = $true
    retainedImageId = $r1Run.imageId
    passed = $true
}
$r1Encoding = [Text.UTF8Encoding]::new($false)
$r1CleanupPath = Join-Path $r1Archive 'cleanup-directory.json'
$r1CleanupText = ($r1Cleanup | ConvertTo-Json -Depth 20).Replace("`r`n", "`n") + "`n"
[IO.File]::WriteAllText($r1CleanupPath, $r1CleanupText, $r1Encoding)
$r1SummaryPath = Join-Path $r1Archive 'summary.json'
$r1Summary = Get-Content -Raw -Encoding UTF8 -LiteralPath $r1SummaryPath | ConvertFrom-Json
$r1Summary.cleanup.temporaryDirectoryRemoved = $true
$r1Summary.cleanup | Add-Member -NotePropertyName directoryEvidence -NotePropertyValue 'cleanup-directory.json' -Force
$r1Summary | Add-Member -NotePropertyName finalizedUtc -NotePropertyValue $r1Cleanup.timeUtc -Force
$r1SummaryText = ($r1Summary | ConvertTo-Json -Depth 40).Replace("`r`n", "`n") + "`n"
[IO.File]::WriteAllText($r1SummaryPath, $r1SummaryText, $r1Encoding)
$r1Manifest.files = @(Get-ChildItem -Force -File -LiteralPath $r1Archive | Where-Object { $_.Name -ne 'artifact-manifest.json' } | Sort-Object Name | ForEach-Object {
    [ordered]@{ path = $_.Name; bytes = $_.Length; sha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $_.FullName).Hash.ToLowerInvariant() }
})
$r1Manifest.generatedUtc = $r1Cleanup.timeUtc
$r1ManifestText = ($r1Manifest | ConvertTo-Json -Depth 20).Replace("`r`n", "`n") + "`n"
[IO.File]::WriteAllText($r1ManifestPath, $r1ManifestText, $r1Encoding)
$r1CleanupText
