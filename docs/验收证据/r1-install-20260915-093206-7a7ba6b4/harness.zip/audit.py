import json
import sys
from r1lib import ROOT, RUN, REPO, counts, now, preservation, resources, save

phase = sys.argv[1]
before = json.loads((ROOT / "private" / "preservation-before.json").read_text(encoding="utf-8"))
current = preservation()
allowed_existing = {
    "docs/R1安装验收准备-2026-09-14.md", "docs/README.md",
    "docs/产品规划/开源发布范围与执行清单-2026-09-13.md",
    "docs/releases/v0.6.1.md",
} if phase == "final" else set()
allowed_new = {"docs/R1安装验收-2026-09-15.md"} if phase == "final" else set()
evidence_prefix = "docs/验收证据/r1-install-" + RUN["runId"] + "/"
changed = [p for p, h in before["workspace"].items() if current["workspace"].get(p) != h]
new = [p for p in current["workspace"] if p not in before["workspace"]]
unexpected_changed = [p for p in changed if p not in allowed_existing]
unexpected_new = [p for p in new if not (p in allowed_new or (phase == "final" and p.startswith(evidence_prefix)))]
original_resources = json.loads((ROOT / "private" / "resources-before.json").read_text(encoding="utf-8"))
current_resources = resources()
for snapshot in (original_resources, current_resources):
    for container in snapshot["containers"]:
        container["mounts"] = sorted(container["mounts"], key=lambda mount: json.dumps(mount, sort_keys=True))
resource_checks = {key: original_resources[key] == current_resources[key] for key in ("containers", "volumes", "networks")}
original_images_retained = set(original_resources["imageIds"]).issubset(set(current_resources["imageIds"]))
report = {
    "runId": RUN["runId"], "phase": phase, "timeUtc": now(),
    "originalWorkspaceFiles": len(before["workspace"]),
    "originalWorkspaceFilesUnchanged": len(before["workspace"]) - len(changed),
    "allowedChangedFiles": sorted(set(changed).intersection(allowed_existing)),
    "unexpectedChangedFiles": unexpected_changed, "unexpectedNewFiles": unexpected_new,
    "approvedNewFilesCount": len(new) - len(unexpected_new),
    "headUnchanged": before["head"] == current["head"],
    "indexUnchanged": before["indexSha256"] == current["indexSha256"],
    "protectedFilesChecked": len(before["protected"]),
    "protectedFilesAndSetUnchanged": before["protected"] == current["protected"],
    "dataMetadataFilesChecked": len(before["dataMetadata"]),
    "dataMetadataUnchanged": before["dataMetadata"] == current["dataMetadata"],
    "originalResources": {key: len(original_resources[key]) for key in ("containers", "volumes", "networks")},
    "originalResourceMetadataUnchanged": resource_checks,
    "containerMountOrderNormalized": True,
    "originalImagesRetained": original_images_retained,
}
report["passed"] = all([
    not unexpected_changed, not unexpected_new, report["headUnchanged"], report["indexUnchanged"],
    report["protectedFilesAndSetUnchanged"], report["dataMetadataUnchanged"],
    all(resource_checks.values()), original_images_retained,
])
save(ROOT / "private" / ("preservation-" + phase + "-full.json"), current)
save(ROOT / "evidence" / ("preservation-" + phase + ".json"), report)
print(json.dumps(report, ensure_ascii=False))
if not report["passed"]:
    sys.exit(1)
