import json
import shutil
import sys
import zipfile
from pathlib import Path
from r1lib import ROOT, RUN, REPO, now, save, sha

archive = REPO / "docs" / "验收证据" / ("r1-install-" + RUN["runId"])
expected_parent = (REPO / "docs" / "验收证据").resolve()
if archive.resolve().parent != expected_parent or archive.is_symlink():
    raise RuntimeError("证据归档目录不符。")
build = json.loads((ROOT / "evidence" / "build.json").read_text(encoding="utf-8"))
if build["status"] == "running":
    raise RuntimeError("构建尚未结束，不能归档为完成记录。")
creds = json.loads((ROOT / "private" / "credentials.json").read_text(encoding="utf-8"))
secret_fields = {k: v.encode("utf-8") for k, v in creds.items() if isinstance(v, str) and len(v) >= 8}
secrets = list(secret_fields.values())


def check_bytes(name, data):
    if any(value in data for value in secrets):
        raise RuntimeError("公开证据包含本轮凭据，停止归档：" + name)


def check_file(path):
    check_bytes(path.name, path.read_bytes())
    if path.suffix == ".zip":
        with zipfile.ZipFile(path) as z:
            if z.testzip() is not None:
                raise RuntimeError("ZIP 校验失败：" + path.name)
            for entry in z.infolist():
                if entry.is_dir():
                    continue
                if entry.filename.startswith("/") or ".." in Path(entry.filename).parts:
                    raise RuntimeError("ZIP 路径异常。")
                check_bytes(path.name + "/" + entry.filename, z.read(entry))


harness_files = [
    "r1lib.py", "prepare.py", "build.py", "runtime.py", "verify-data.py",
    "audit.py", "browser-driver.cjs", "browser-launch.py", "archive-evidence.py", "verify-documents.py", "compose.base.yml",
    "compose.r1.yml", "nginx/demo.conf", "record-results.py", "cleanup-directory.ps1",
]
harness_redactions = []
with zipfile.ZipFile(ROOT / "evidence" / "harness.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for relative in sorted(harness_files):
        data = (ROOT / relative).read_bytes()
        for field, value in secret_fields.items():
            if value in data:
                data = data.replace(value, ("[REDACTED_" + field + "]").encode("utf-8"))
                harness_redactions.append({"file": relative, "field": field})
        check_bytes(relative, data)
        entry = zipfile.ZipInfo(relative, date_time=(1980, 1, 1, 0, 0, 0))
        entry.compress_type = zipfile.ZIP_DEFLATED
        z.writestr(entry, data)

save(ROOT / "evidence" / "run-identity.json", {
    k: v for k, v in RUN.items() if k not in {"root", "repository", "tempParent"}
})
save(ROOT / "evidence" / "archive-redaction.json", {"harnessLiteralRedactions": harness_redactions, "privateCredentialsArchived": False})
log_names = sorted(p.name for p in (ROOT / "evidence").glob("*.log"))
(ROOT / "evidence" / ".gitignore").write_text("# 本轮已脱敏日志随验收记录保存。\n" + "".join("!/" + name + "\n" for name in log_names), encoding="utf-8", newline="\n")
source_files = sorted(p for p in (ROOT / "evidence").iterdir() if p.is_file() and p.name != "artifact-manifest.json")
for path in source_files:
    if path.name != ".gitignore" and path.suffix not in {".json", ".jsonl", ".log", ".txt", ".png", ".zip", ".md"}:
        raise RuntimeError("未知公开证据类型：" + path.name)
    if path.is_symlink():
        raise RuntimeError("证据不能使用符号链接。")
    if path.suffix in {".json", ".jsonl", ".log", ".txt", ".md"}:
        content = path.read_text(encoding="utf-8-sig").replace("\r\n", "\n")
        path.write_text(content, encoding="utf-8", newline="\n")
    check_file(path)

archive.mkdir(parents=True, exist_ok=True)
existing = {p.name for p in archive.iterdir()}
expected = {p.name for p in source_files} | {"artifact-manifest.json"}
if not existing.issubset(expected):
    raise RuntimeError("归档目录包含未知文件，停止覆盖。")
for path in source_files:
    target = archive / path.name
    shutil.copyfile(path, target)
    if sha(path) != sha(target):
        raise RuntimeError("证据复制哈希不符：" + path.name)
manifest = {
    "runId": RUN["runId"], "generatedUtc": now(),
    "credentialScanPassed": True,
    "files": [{"path": p.name, "bytes": p.stat().st_size, "sha256": sha(p)} for p in source_files],
}
save(ROOT / "evidence" / "artifact-manifest.json", manifest)
save(archive / "artifact-manifest.json", manifest)
print(json.dumps({"archived": True, "files": len(source_files), "directory": str(archive), "credentialScanPassed": True}, ensure_ascii=False))
