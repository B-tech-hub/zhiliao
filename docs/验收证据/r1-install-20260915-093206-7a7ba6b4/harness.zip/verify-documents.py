import difflib
import json
import re
import sys
from urllib.parse import unquote, urlsplit
from r1lib import ROOT, RUN, REPO, now, save, sha

existing = [
    "docs/R1安装验收准备-2026-09-14.md", "docs/README.md",
    "docs/产品规划/开源发布范围与执行清单-2026-09-13.md",
    "docs/releases/v0.6.1.md",
]
paths = existing + ["docs/R1安装验收-2026-09-15.md"]
baseline = ROOT / "private" / "documents-before.json"
if sys.argv[1] == "baseline":
    if baseline.exists():
        raise RuntimeError("文档基线已存在。")
    save(baseline, {p: (REPO / p).read_text(encoding="utf-8") for p in existing})
    print(json.dumps({"baselineSaved": True, "files": len(existing)}))
    sys.exit(0)

before = json.loads(baseline.read_text(encoding="utf-8"))
results = []
for relative in paths:
    path = REPO / relative
    data = path.read_bytes()
    assert not data.startswith(b"\xef\xbb\xbf") and b"\r" not in data
    text = data.decode("utf-8")
    assert text.endswith("\n")
    lines = text.splitlines()
    assert sum(bool(re.match(r"^\s*```", line)) for line in lines) % 2 == 0
    diff = list(difflib.unified_diff(before.get(relative, "").splitlines(), lines))
    added = [line[1:] for line in diff if line.startswith("+") and not line.startswith("+++")]
    assert not any(line != line.rstrip() for line in added)
    links = []
    for line in added:
        for target in re.findall(r"!?\[[^\]]*\]\(([^)]+)\)", line):
            target = target.strip("<>")
            parsed = urlsplit(target)
            if parsed.scheme or parsed.netloc:
                continue
            linked = (path.parent / unquote(parsed.path)).resolve() if parsed.path else path
            assert linked.exists(), (relative, target)
            if parsed.fragment and linked.suffix == ".md":
                content = linked.read_text(encoding="utf-8")
                anchor = unquote(parsed.fragment)
                ids = set(re.findall(r'id="([^"]+)"', content))
                for heading in re.findall(r"^#{1,6}\s+(.+)$", content, flags=re.MULTILINE):
                    slug = re.sub(r"[^\w\s-]", "", heading.lower()).replace(" ", "-")
                    ids.add(slug)
                assert anchor in ids, (relative, target, "anchor")
            links.append(target)
    results.append({"file": relative, "sha256": sha(path), "addedLines": len(added), "newRelativeLinks": links, "passed": True})

report = {"runId": RUN["runId"], "timeUtc": now(), "files": results, "utf8Lf": True, "fencesPaired": True, "incrementalWhitespacePassed": True, "newLinksPassed": True, "passed": True}
save(ROOT / "evidence" / "document-verification.json", report)
print(json.dumps({"passed": True, "files": len(results), "newRelativeLinks": sum(len(r["newRelativeLinks"]) for r in results)}, ensure_ascii=False))
