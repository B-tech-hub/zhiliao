// 本轮使用独立浏览器目录，串行接收操作并保存脱敏证据。
const fs = require("node:fs");
const path = require("node:path");
const readline = require("node:readline");
const { chromium } = require("C:/Users/BAIBAI/AppData/Local/npm-cache/_npx/9833c18b2d85bc59/node_modules/playwright");
const root = __dirname;
const run = JSON.parse(fs.readFileSync(path.join(root, "run.json"), "utf8"));
const origin = "http://127.0.0.1:" + run.port;
const reportPath = path.join(root, "evidence", "browser-report.json");
const r = { runId: run.runId, startedUtc: new Date().toISOString(), network: [], console: [], errors: [], blocked: [], steps: {}, currentAction: null, driverPid: process.pid };
const save = () => fs.writeFileSync(reportPath, JSON.stringify(r, null, 2) + "\n");
const h = {
  root, origin,
  evidence: name => path.join(root, "evidence", name),
  credentials: () => JSON.parse(fs.readFileSync(path.join(root, "private", "credentials.json"), "utf8")),
  record: (name, value) => {
    r.steps[name] = value;
    fs.writeFileSync(path.join(root, "evidence", "browser-" + name + ".json"), JSON.stringify(value, null, 2) + "\n");
    save();
    return value;
  }
};
(async () => {
  const context = await chromium.launchPersistentContext(path.join(root, "browser-profile"), {
    executablePath: "C:/Program Files/Google/Chrome/Application/chrome.exe",
    headless: true, viewport: { width: 1440, height: 900 }, locale: "zh-CN",
    colorScheme: "light", serviceWorkers: "block", acceptDownloads: true,
    args: ["--no-proxy-server", "--disable-background-networking", "--disable-component-update", "--disable-sync", "--no-first-run", "--no-default-browser-check"]
  });
  const p = context.pages()[0] || await context.newPage();
  r.browserVersion = context.browser()?.version();
  p.setDefaultTimeout(60000);
  p.setDefaultNavigationTimeout(60000);
  await context.route("**/*", async route => {
    const u = new URL(route.request().url());
    if (["http:", "https:"].includes(u.protocol) && u.origin !== origin) {
      r.blocked.push({ origin: u.origin, path: u.pathname, action: r.currentAction });
      save();
      await route.abort("blockedbyclient");
    } else await route.continue();
  });
  p.on("response", res => {
    try { r.network.push({ time: new Date().toISOString(), path: new URL(res.url()).pathname, method: res.request().method(), status: res.status(), action: r.currentAction }); } catch {}
  });
  p.on("requestfailed", req => {
    r.errors.push({ kind: "requestfailed", path: new URL(req.url()).pathname, error: req.failure()?.errorText, action: r.currentAction });
  });
  p.on("console", msg => {
    if (["error", "warning"].includes(msg.type())) r.console.push({ type: msg.type(), text: msg.text(), action: r.currentAction });
  });
  p.on("pageerror", err => r.errors.push({ kind: "pageerror", error: String(err), action: r.currentAction }));
  save();
  console.log(JSON.stringify({ ready: true, browserVersion: r.browserVersion, driverPid: process.pid, origin }));
  const lines = readline.createInterface({ input: process.stdin, crlfDelay: Infinity });
  let chain = Promise.resolve();
  lines.on("line", line => {
    chain = chain.then(async () => {
      if (!line.trim()) return;
      const command = JSON.parse(line);
      fs.appendFileSync(path.join(root, "evidence", "browser-actions.jsonl"), JSON.stringify({ timeUtc: new Date().toISOString(), ...command }) + "\n");
      r.currentAction = command.id;
      if (command.close) {
        r.finishedUtc = new Date().toISOString();
        await context.close();
        save();
        console.log(JSON.stringify({ id: command.id, closed: true }));
        process.exit(0);
      }
      try {
        const execute = new (Object.getPrototypeOf(async function(){}).constructor)("p", "r", "require", "h", command.code);
        const value = await execute(p, r, require, h);
        save();
        console.log(JSON.stringify({ id: command.id, result: value }));
      } catch (e) {
        r.steps[command.id + "-failure"] = { error: String(e) };
        save();
        console.log(JSON.stringify({ id: command.id, error: String(e), stack: e.stack }));
      }
    }).catch(e => console.log(JSON.stringify({ driverError: String(e) })));
  });
})().catch(e => { console.error(e); process.exit(1); });
