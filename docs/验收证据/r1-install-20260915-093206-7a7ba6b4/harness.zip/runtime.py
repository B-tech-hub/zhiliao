import json
import socket
import subprocess
import sys
import time
import urllib.request
from r1lib import ROOT, RUN, HIDDEN, clean_env, command, compose_args, docker, now, save, sha

ACTION = sys.argv[1]
origin = "http://127.0.0.1:" + str(RUN["port"])

def own_ids(kind):
    prefix = {"container": ["ps", "-aq", "--no-trunc"], "volume": ["volume", "ls", "-q"], "network": ["network", "ls", "-q", "--no-trunc"]}[kind]
    return docker(*prefix, "--filter", "label=com.docker.compose.project=" + RUN["project"]).split()

def owned():
    result = {}
    for kind in ("container", "volume", "network"):
        ids = own_ids(kind)
        entries = json.loads(docker(kind, "inspect", *ids)) if ids else []
        for entry in entries:
            labels = entry["Config"].get("Labels", {}) if kind == "container" else entry.get("Labels", {})
            if labels.get("io.zhiliao.r1.run") != RUN["runId"]:
                raise RuntimeError("发现运行标签不符的资源，停止操作。")
        result[kind] = entries
    return result

def run_compose(args, phase, timeout=240):
    started = time.monotonic()
    report = {"runId": RUN["runId"], "phase": phase, "startedUtc": now(), "arguments": args}
    save(ROOT / "evidence" / (phase + ".json"), report)
    result = subprocess.run(compose_args() + args, cwd=ROOT, env=clean_env(), capture_output=True, timeout=timeout, creationflags=HIDDEN)
    output = result.stdout + result.stderr
    (ROOT / "evidence" / (phase + ".log")).write_bytes(output)
    report.update(exitCode=result.returncode, elapsedSeconds=round(time.monotonic() - started, 3), finishedUtc=now())
    save(ROOT / "evidence" / (phase + ".json"), report)
    sys.stdout.buffer.write(output)
    sys.stdout.buffer.flush()
    if result.returncode:
        raise RuntimeError("本轮 Compose 操作失败，详见 " + phase + ".log")
    return report

def config():
    parsed = json.loads(command(compose_args() + ["config", "--format", "json"], cwd=ROOT))
    creds = json.loads((ROOT / "private" / "credentials.json").read_text(encoding="utf-8"))
    assert set(parsed["services"]) == {"app", "mockllm", "ingress"}
    assert set(parsed["volumes"]) == {"install_db", "install_uploads"}
    assert set(parsed["networks"]) == {"demo_net", "ingress_net"}
    for section in ("services", "volumes", "networks"):
        for entry in parsed[section].values():
            assert entry["labels"]["io.zhiliao.r1.run"] == RUN["runId"]
    app = parsed["services"]["app"]
    env = app["environment"]
    assert env["DEMO_MODE"] == "0" and env["NODE_ENV"] == "production"
    assert env["APP_PASSWORD"] == creds["password"] and env["SESSION_SECRET"] == creds["sessionSecret"]
    assert not any(env.get("LLM_" + part) for part in ("BASE_URL", "API_KEY", "MODEL"))
    for prefix in ("VISION", "IMAGE", "REASONING", "EMBEDDING"):
        assert not any(env.get(prefix + "_" + part) for part in ("BASE_URL", "API_KEY", "MODEL"))
    for service in ("app", "mockllm"):
        assert parsed["services"][service]["image"] == RUN["imageId"]
        assert set(parsed["services"][service]["networks"]) == {"demo_net"}
        assert not parsed["services"][service].get("ports")
    for service in parsed["services"].values():
        assert service["restart"] == "no" and service["pull_policy"] == "never"
        assert service["read_only"] is True
    ingress_ports = parsed["services"]["ingress"]["ports"]
    assert len(ingress_ports) == 1 and ingress_ports[0]["host_ip"] == "127.0.0.1"
    assert int(ingress_ports[0]["published"]) == RUN["port"]
    assert parsed["networks"]["demo_net"]["internal"]
    assert parsed["networks"]["demo_net"]["driver_opts"]["com.docker.network.bridge.gateway_mode_ipv4"] == "isolated"
    assert not parsed["networks"]["ingress_net"].get("internal", False)
    mounts = {v["target"]: v for v in app["volumes"]}
    assert mounts["/data/db"]["source"] == "install_db" and mounts["/data/db"]["type"] == "volume"
    assert mounts["/data/uploads"]["source"] == "install_uploads" and mounts["/data/uploads"]["type"] == "volume"
    assert mounts["/data/notes"]["type"] == "bind"
    assert PathNormalized(mounts["/data/notes"]["source"]) == PathNormalized(str(ROOT / "notes"))
    save(ROOT / "private" / "config.json", parsed)
    env["APP_PASSWORD"] = "[本轮随机密码]"
    env["SESSION_SECRET"] = "[本轮随机密钥]"
    save(ROOT / "evidence" / "config-redacted.json", parsed)
    return parsed

def PathNormalized(value):
    return value.replace("\\", "/").lower()

def runtime_snapshot(phase):
    state = owned()
    assert len(state["container"]) == 3 and len(state["volume"]) == 2 and len(state["network"]) == 2
    cards = []
    app_id = None
    for entry in state["container"]:
        service = entry["Config"]["Labels"]["com.docker.compose.service"]
        assert entry["State"]["Running"]
        assert entry["State"]["Health"]["Status"] == "healthy"
        if service in ("app", "mockllm"):
            assert entry["Image"] == RUN["imageId"]
            assert list(entry["NetworkSettings"]["Networks"]) == [RUN["project"] + "-net"]
            assert not entry["HostConfig"].get("PortBindings")
        if service == "app":
            app_id = entry["Id"]
        if service == "ingress":
            expected_binding = [{"HostIp": "127.0.0.1", "HostPort": str(RUN["port"])}]
            assert entry["HostConfig"]["PortBindings"].get("8080/tcp") == expected_binding
            assert entry["NetworkSettings"]["Ports"].get("8080/tcp") == expected_binding
        cards.append({
            "id": entry["Id"], "service": service, "name": entry["Name"],
            "imageId": entry["Image"], "health": entry["State"]["Health"]["Status"],
            "networks": list(entry["NetworkSettings"]["Networks"]),
            "portBindings": entry["HostConfig"].get("PortBindings"),
            "mounts": entry["Mounts"], "readOnly": entry["HostConfig"]["ReadonlyRootfs"],
            "memoryLimit": entry["HostConfig"]["Memory"], "nanoCpus": entry["HostConfig"]["NanoCpus"],
        })
    response = urllib.request.urlopen(origin + "/api/healthz", timeout=10)
    health = {"status": response.status, "body": json.loads(response.read())}
    payload = json.dumps({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}}).encode()
    req = urllib.request.Request(origin + "/api/mcp", data=payload, headers={"Content-Type": "application/json"})
    response = urllib.request.urlopen(req, timeout=10)
    mcp = json.loads(response.read())
    assert mcp["result"]["serverInfo"]["version"] == "0.6.1"
    snapshot = {
        "runId": RUN["runId"], "phase": phase, "timeUtc": now(), "containers": cards,
        "volumes": [{"name": v["Name"], "labels": v["Labels"]} for v in state["volume"]],
        "networks": [{"id": n["Id"], "name": n["Name"], "internal": n["Internal"], "options": n["Options"], "ipam": n["IPAM"]} for n in state["network"]],
        "health": health, "mcp": {"status": response.status, "result": mcp["result"]},
    }
    save(ROOT / "evidence" / (phase + "-runtime.json"), snapshot)
    return app_id, snapshot

try:
    if ACTION == "start":
        if not RUN.get("imageId", "").startswith("sha256:"):
            raise RuntimeError("缺少实际候选镜像 ID。")
        if any(owned().values()):
            raise RuntimeError("初次启动前已有本轮资源。")
        if any((ROOT / "notes").iterdir()):
            raise RuntimeError("初始 Markdown 目标不是空目录。")
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
            probe.bind(("127.0.0.1", RUN["port"]))
        config()
        run_compose(["up", "-d", "--no-build", "--pull", "never", "--wait", "--wait-timeout", "180"], "startup")
        app_id, result = runtime_snapshot("initial")
        code = "const db=new (require('better-sqlite3'))(process.env.DATABASE_PATH,{readonly:true,fileMustExist:true});const r={notes:db.prepare('select count(*) as n from notes').get().n,models:db.prepare(\"select key from settings where key in ('llm_base_url','llm_api_key','llm_model','vision_model','image_model','reasoning_model','embedding_model')\").all()};db.close();process.stdout.write(JSON.stringify(r));"
        initial_db = json.loads(docker("exec", app_id, "node", "-e", code))
        assert initial_db["notes"] == 0 and not initial_db["models"]
        save(ROOT / "evidence" / "initial-empty-db.json", initial_db)
        print(json.dumps({"started": True, "servicesHealthy": 3, "imageId": RUN["imageId"], "version": "0.6.1", "initialDb": initial_db, "origin": origin}))
    elif ACTION == "repair-start":
        owned()
        config()
        run_compose(["down", "--timeout", "15"], "startup-config-down")
        run_compose(["up", "-d", "--no-build", "--pull", "never", "--wait", "--wait-timeout", "180"], "startup-config-up")
        app_id, result = runtime_snapshot("initial")
        code = "const db=new (require('better-sqlite3'))(process.env.DATABASE_PATH,{readonly:true,fileMustExist:true});const r={notes:db.prepare('select count(*) as n from notes').get().n,models:db.prepare(\"select key from settings where key in ('llm_base_url','llm_api_key','llm_model','vision_model','image_model','reasoning_model','embedding_model')\").all()};db.close();process.stdout.write(JSON.stringify(r));"
        initial_db = json.loads(docker("exec", app_id, "node", "-e", code))
        assert initial_db["notes"] == 0 and not initial_db["models"]
        save(ROOT / "evidence" / "initial-empty-db.json", initial_db)
        print(json.dumps({"started": True, "servicesHealthy": 3, "imageId": RUN["imageId"], "version": "0.6.1", "initialDb": initial_db, "origin": origin}))
    elif ACTION == "restart":
        owned()
        config()
        run_compose(["down", "--timeout", "15"], "restart-down")
        run_compose(["up", "-d", "--no-build", "--pull", "never", "--wait", "--wait-timeout", "180"], "restart-up")
        _, result = runtime_snapshot("restart")
        print(json.dumps({"restarted": True, "servicesHealthy": 3, "version": result["mcp"]["result"]["serverInfo"]["version"]}))
    elif ACTION == "inspect":
        _, result = runtime_snapshot("inspection")
        print(json.dumps({"healthy": True, "containers": len(result["containers"]), "imageId": RUN["imageId"]}))
    elif ACTION == "logs":
        state = owned()
        output = command(compose_args() + ["logs", "--no-color", "--timestamps"], cwd=ROOT)
        (ROOT / "evidence" / "runtime.log").write_text(output, encoding="utf-8", newline="\n")
        print(json.dumps({"logsSaved": True, "bytes": len(output.encode("utf-8"))}))
    elif ACTION == "stop":
        owned()
        run_compose(["stop", "--timeout", "15"], "stop-after-failure")
    elif ACTION == "cleanup":
        state = owned()
        save(ROOT / "private" / "resources-before-cleanup.json", state)
        run_compose(["down", "-v", "--timeout", "15"], "cleanup-compose")
        remaining = owned()
        assert not any(remaining.values())
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
            probe.bind(("127.0.0.1", RUN["port"]))
        report = {"runId": RUN["runId"], "timeUtc": now(), "containersRemoved": len(state["container"]), "volumesRemoved": len(state["volume"]), "networksRemoved": len(state["network"]), "remainingOwnedResources": 0, "portReleased": True, "imageRetained": RUN.get("imageId"), "temporaryDirectoryRemoved": False, "passed": True}
        save(ROOT / "evidence" / "cleanup-runtime.json", report)
        print(json.dumps(report))
    else:
        raise RuntimeError("未知操作。")
except Exception as e:
    save(ROOT / "evidence" / ("runtime-" + ACTION + "-failure.json"), {"timeUtc": now(), "action": ACTION, "error": str(e)})
    raise
