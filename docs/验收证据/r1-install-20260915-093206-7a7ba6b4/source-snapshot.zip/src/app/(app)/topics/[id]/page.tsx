import Link from "next/link";
import { notFound } from "next/navigation";
import { and, desc, eq, isNull } from "drizzle-orm";
import { getDb } from "@/db";
import { notes, topics } from "@/db/schema";
import { getTagsForNotes } from "@/lib/notes";
import { toClientNote } from "@/lib/client-note";
import { BackButton } from "@/components/back-button";
import { EmptyNotes } from "@/components/note-card";
import { ChatScopeBinder } from "@/components/chat/chat-scope";
import { AskWithSourcesButton } from "@/components/chat/ask-with-sources";
import { TopicNotes } from "./topic-notes";

export const dynamic = "force-dynamic";

export default async function TopicPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const db = getDb();
  const topic = db.select().from(topics).where(eq(topics.id, id)).get();
  if (!topic) notFound();

  const rows = db
    .select()
    .from(notes)
    .where(and(eq(notes.topicId, id), isNull(notes.deletedAt)))
    .orderBy(desc(notes.updatedAt))
    .limit(200)
    .all();
  const tagMap = getTagsForNotes(db, rows.map((n) => n.id));

  return (
    <div>
      <BackButton fallback="/" className="mb-4" />
      <div className="mb-8 flex items-end justify-between gap-4">
        <header className="min-w-0">
          <p className="mb-2 text-[12px] font-semibold tracking-[0.06em] text-ink-48">主题</p>
          <h1 className="truncate font-serif text-display leading-[1.1] tracking-[-0.4px]">
            {topic.name}
          </h1>
          <p className="mt-2 font-mono text-meta text-ink-48">{rows.length} 条笔记</p>
        </header>
        <div className="flex shrink-0 items-center gap-3">
          <AskWithSourcesButton
            type="topic"
            id={topic.id}
            label={topic.name}
            className="rounded-utility border border-hairline px-4 py-1.5 text-[14px] text-ink-48 transition-colors hover:text-action active:scale-95"
          />
          <Link
            href={`/notes/new?topic=${topic.id}`}
            className="rounded-utility bg-cta px-4 py-1.5 text-[14px] text-cta-ink transition-transform active:scale-95"
          >
            新笔记
          </Link>
        </div>
      </div>
      {rows.length === 0 ? (
        <EmptyNotes hint="这个主题下还没有笔记" />
      ) : (
        <TopicNotes notes={rows.map((n) => ({ ...toClientNote(n), tags: tagMap.get(n.id) ?? [] }))} />
      )}
      {/* 把这个主题登记为助手的上下文附件；助手面板本身挂在 (app)/layout */}
      <ChatScopeBinder type="topic" id={topic.id} title={topic.name} />
    </div>
  );
}
