import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { getDb } from "@/db";
import { trashNotes } from "@/lib/trash";

const bodySchema = z.object({
  noteIds: z.array(z.string()).min(1).max(200),
});

// 批量删除 = 批量移入回收站，30 天内可在 设置 → 回收站 恢复
export async function POST(req: NextRequest) {
  const parsed = bodySchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: "参数不合法" }, { status: 400 });
  }
  const trashed = trashNotes(getDb(), parsed.data.noteIds);
  return NextResponse.json({ ok: true, trashed });
}
