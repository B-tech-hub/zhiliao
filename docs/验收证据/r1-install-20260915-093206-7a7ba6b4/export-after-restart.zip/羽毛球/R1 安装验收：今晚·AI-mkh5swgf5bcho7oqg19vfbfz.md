---
id: "mkh5swgf5bcho7oqg19vfbfz"
title: "R1 安装验收：今晚·AI"
topic: "羽毛球"
tags: ["羽毛球", "训练"]
created: 2026-09-15T02:30:27.870Z
updated: 2026-09-15T02:30:27.903Z
---

R1 安装验收：今晚羽毛球训练，杀球有下压
