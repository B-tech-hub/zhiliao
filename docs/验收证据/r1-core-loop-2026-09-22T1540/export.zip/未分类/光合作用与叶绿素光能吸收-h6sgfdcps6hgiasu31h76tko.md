---
id: "h6sgfdcps6hgiasu31h76tko"
title: "光合作用与叶绿素光能吸收"
topic: "未分类"
tags: ["光合作用", "叶绿素", "生物学"]
created: 2026-09-22T15:40:45.965Z
updated: 2026-09-22T15:43:32.030Z
---

光合作用需要叶绿素吸收光能
