---
id: "nyqfmgdxr93x1x7wq2ocz33u"
title: "Markdown表格对齐语法"
topic: "未分类"
tags: ["Markdown", "排版技巧", "表格语法"]
created: 2026-09-22T15:40:44.910Z
updated: 2026-09-22T15:49:07.204Z
---

Markdown 表格用 `:---` 左对齐、`:---:` 居中、`---:` 右对齐
