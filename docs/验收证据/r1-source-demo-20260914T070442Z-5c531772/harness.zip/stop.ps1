﻿param([Parameter(Mandatory=$true)][ValidateSet('cold','restart')][string]$Phase)
$ErrorActionPreference = 'Stop'
$r1Root = [System.IO.Path]::GetFullPath($PSScriptRoot)
$r1Marker = Get-Content -Raw -Encoding UTF8 -LiteralPath (Join-Path $r1Root 'run-marker.json') | ConvertFrom-Json
if ($r1Marker.root -ne $r1Root) { throw '运行标记与目录不一致。' }
$r1RecordPath = Join-Path $r1Root ('process-' + $Phase + '.json')
if (-not (Test-Path -LiteralPath $r1RecordPath)) { throw '缺少本轮进程记录。' }
$r1Record = Get-Content -Raw -Encoding UTF8 -LiteralPath $r1RecordPath | ConvertFrom-Json
$r1All = @(Get-CimInstance Win32_Process)
$r1Ids = [System.Collections.Generic.HashSet[int]]::new()
$r1RootProcess = $r1All | Where-Object { $_.ProcessId -eq $r1Record.pid }
if ($r1RootProcess) {
    if ($r1RootProcess.CommandLine -notlike ('*' + $r1Root + '\run-demo.ps1*')) { throw '父进程身份已变化。' }
    if ([Math]::Abs(($r1RootProcess.CreationDate.ToUniversalTime() - [DateTime]::Parse($r1Record.startUtc).ToUniversalTime()).TotalSeconds) -gt 3) { throw '父进程创建时间已变化。' }
    [void]$r1Ids.Add([int]$r1Record.pid)
}
$r1NetworkPath = Join-Path $r1Root ('evidence\network-' + $Phase + '.jsonl')
if (Test-Path -LiteralPath $r1NetworkPath) {
    foreach ($r1Line in Get-Content -Encoding UTF8 -LiteralPath $r1NetworkPath) {
        try { $r1Event = $r1Line | ConvertFrom-Json } catch { continue }
        if ($r1Event.event -ne 'process') { continue }
        $r1Node = $r1All | Where-Object { $_.ProcessId -eq $r1Event.pid }
        if ($r1Node -and $r1Node.Name -eq 'node.exe') {
            $r1Age = ([DateTime]::Parse($r1Event.time).ToUniversalTime() - $r1Node.CreationDate.ToUniversalTime()).TotalSeconds
            if ($r1Age -ge -2 -and $r1Age -le 30) { [void]$r1Ids.Add([int]$r1Node.ProcessId) }
        }
    }
}
do {
    $r1Added = $false
    foreach ($r1Process in $r1All) {
        if ($r1Ids.Contains([int]$r1Process.ParentProcessId) -and -not $r1Ids.Contains([int]$r1Process.ProcessId)) {
            [void]$r1Ids.Add([int]$r1Process.ProcessId)
            $r1Added = $true
        }
    }
} while ($r1Added)
$r1Stopped = @()
foreach ($r1Process in ($r1All | Where-Object { $r1Ids.Contains([int]$_.ProcessId) } | Sort-Object CreationDate -Descending)) {
    $r1Live = Get-Process -Id $r1Process.ProcessId -ErrorAction SilentlyContinue
    if ($r1Live) {
        $r1Birth = $r1Live.StartTime
        if ($r1Live.HasExited -or $null -eq $r1Birth) { continue }
        if ([Math]::Abs(($r1Birth.ToUniversalTime() - $r1Process.CreationDate.ToUniversalTime()).TotalSeconds) -gt 3) { throw '进程 PID 已被复用。' }
        Stop-Process -Id $r1Process.ProcessId -Force -ErrorAction Stop
        $r1Stopped += @{ pid = [int]$r1Process.ProcessId; name = $r1Process.Name }
    }
}
Start-Sleep -Milliseconds 700
$r1Remaining = @(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Where-Object { $_.LocalPort -in @(3311,8787) })
$r1Result = @{ phase = $Phase; stopped = $r1Stopped; remainingListeners = @($r1Remaining | Select-Object LocalAddress,LocalPort,OwningProcess); passed = ($r1Remaining.Count -eq 0); timeUtc = [DateTime]::UtcNow.ToString('o') }
[System.IO.File]::WriteAllText((Join-Path $r1Root ('evidence\stop-' + $Phase + '.json')), ($r1Result | ConvertTo-Json -Depth 8), [System.Text.UTF8Encoding]::new($false))
$r1Result | ConvertTo-Json -Depth 8 -Compress
if ($r1Remaining.Count -gt 0) { throw '验收端口仍有监听，保留现场。' }
