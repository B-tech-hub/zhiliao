import base64
import hashlib
import json
import os
import shutil
import subprocess
import time
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parent
marker = json.loads((root / "run-marker.json").read_text(encoding="utf-8-sig"))
source = Path(marker["source"])
candidate = root / "candidate"
evidence = root / "evidence"
evidence.mkdir()
candidate.mkdir()
def digest(p):
    h = hashlib.sha256()
    with p.open("rb") as f:
        for part in iter(lambda: f.read(1024 * 1024), b""):
            h.update(part)
    return h.hexdigest()
def output(name, data):
    (root / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
listed = subprocess.check_output(["git", "ls-files", "-z", "--cached", "--others", "--exclude-standard"], cwd=source)
paths = sorted(set(x.decode("utf-8") for x in listed.split(b"\0") if x))
workspace = {p: digest(source / p) for p in paths if (source / p).is_file()}
data_manifest = {}
private_hashes = {}
for p in source.glob(".env*"):
    if p.is_file():
        private_hashes[p.name] = digest(p)
for directory in source.glob("data*"):
    if not directory.is_dir():
        continue
    for p in directory.rglob("*"):
        if p.is_file():
            rel = p.relative_to(source).as_posix()
            st = p.stat()
            data_manifest[rel] = [st.st_size, st.st_mtime_ns]
            if p.suffix in (".db", ".sqlite", ".sqlite3") or p.name.endswith(("-wal", "-shm")):
                private_hashes[rel] = digest(p)
output("preservation-before-private.json", {
    "head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=source, text=True).strip(),
    "index": digest(source / ".git" / "index"),
    "workspace": workspace, "dataMetadata": data_manifest, "protectedHashes": private_hashes
})
root_files = [
    "package.json", "package-lock.json", "next.config.ts", "next-env.d.ts",
    "tsconfig.json", "postcss.config.mjs", ".gitignore", ".gitattributes"
]
for name in ["src", "scripts", "public"]:
    shutil.copytree(source / name, candidate / name)
for name in root_files:
    shutil.copy2(source / name, candidate / name)
code_manifest = {}
for p in candidate.rglob("*"):
    if p.is_file():
        rel = p.relative_to(candidate).as_posix()
        sha = digest(p)
        if sha != digest(source / rel):
            raise RuntimeError("候选复制哈希不一致: " + rel)
        code_manifest[rel] = sha
output("evidence/candidate-manifest.json", code_manifest)
print(json.dumps({"stage": "source-copied", "files": len(code_manifest), "workspaceFiles": len(workspace), "protectedDataFiles": len(data_manifest)}, ensure_ascii=False), flush=True)
started = time.monotonic()
shutil.copytree(source / "node_modules", candidate / "node_modules")
print(json.dumps({"stage": "dependencies-copied", "seconds": round(time.monotonic() - started, 2)}), flush=True)
fixtures = root / "fixtures"
fixtures.mkdir()
with zipfile.ZipFile(fixtures / "r1-import.zip", "w", zipfile.ZIP_DEFLATED) as z:
    z.writestr("R1验收/导入拦截.md", "---\ntitle: R1导入拦截\n---\n\n此笔记只用于验证 Demo 返回 403。\n")
png = base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+a7xkAAAAASUVORK5CYII=")
(fixtures / "r1-upload.png").write_bytes(png)
(root / "empty-user.npmrc").write_text("", encoding="utf-8")
(root / "empty-global.npmrc").write_text("", encoding="utf-8")
output("evidence/preparation.json", {
    "runId": marker["runId"], "sourceFiles": len(code_manifest), "candidateVersion": json.loads((candidate / "package.json").read_text(encoding="utf-8"))["version"],
    "nodeVersion": subprocess.check_output(["node", "--version"], text=True).strip(),
    "dependencyMethod": "physical-copy-existing-node_modules",
    "sourceSha256Verified": True, "originalEnvOrDataCopied": False,
    "fixtures": {p.name: {"bytes": p.stat().st_size, "sha256": digest(p)} for p in fixtures.iterdir()}
})
print("PREPARATION_COMPLETE", flush=True)
