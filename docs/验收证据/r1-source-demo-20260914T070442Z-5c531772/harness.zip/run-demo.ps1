﻿$ErrorActionPreference = 'Stop'
$r1Root = $PSScriptRoot
$r1Candidate = Join-Path $r1Root 'candidate'
$r1KeepEnv = @('PATH','PATHEXT','SystemRoot','WINDIR','COMSPEC','TEMP','TMP','USERPROFILE','HOMEDRIVE','HOMEPATH','HOME','CODEX_HOME','APPDATA','LOCALAPPDATA','ProgramData','ProgramFiles','ProgramFiles(x86)','CommonProgramFiles','CommonProgramFiles(x86)','PROCESSOR_ARCHITECTURE','NUMBER_OF_PROCESSORS','OS','R1_PHASE')
foreach ($r1Entry in Get-ChildItem Env:) {
    if ($r1Entry.Name -notin $r1KeepEnv) {
        [Environment]::SetEnvironmentVariable($r1Entry.Name, $null, 'Process')
    }
}
Set-Location -LiteralPath $r1Candidate
$env:PORT = '3311'
$env:NEXT_DIST_DIR = '.next-r1'
$env:NEXT_TELEMETRY_DISABLED = '1'
$env:TZ = 'Asia/Shanghai'
$env:NODE_OPTIONS = '--require "' + (Join-Path $r1Root 'local-only.cjs').Replace('\','/') + '"'
$env:NPM_CONFIG_USERCONFIG = Join-Path $r1Root 'empty-user.npmrc'
$env:NPM_CONFIG_GLOBALCONFIG = Join-Path $r1Root 'empty-global.npmrc'
$env:NPM_CONFIG_CACHE = Join-Path $r1Root '.npm-cache'
$env:NPM_CONFIG_UPDATE_NOTIFIER = 'false'
$env:NPM_CONFIG_AUDIT = 'false'
$env:NPM_CONFIG_FUND = 'false'
$env:DEMO_MODE = '0'
$env:DEMO_RUNTIME = 'r1-invalid'
$env:APP_PASSWORD = 'r1-host-canary'
$env:SESSION_SECRET = 'r1-host-canary-session-secret-012345'
$env:DATABASE_PATH = './canary/db/app.db'
$env:UPLOAD_DIR = './canary/uploads'
$env:NOTES_EXPORT_DIR = './canary/notes'
$env:DEMO_LLM_BASE_URL = 'http://127.0.0.1:18787/v1'
foreach ($r1Prefix in @('LLM','EMBEDDING','VISION','IMAGE','REASONING')) {
    [Environment]::SetEnvironmentVariable($r1Prefix + '_BASE_URL', 'http://127.0.0.1:18787/v1', 'Process')
    [Environment]::SetEnvironmentVariable($r1Prefix + '_API_KEY', 'r1-host-canary', 'Process')
    [Environment]::SetEnvironmentVariable($r1Prefix + '_MODEL', 'r1-host-canary', 'Process')
}
& 'D:\node.js\npm.cmd' run demo
exit $LASTEXITCODE
