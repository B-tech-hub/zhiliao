const http = require("node:http");
const net = require("node:net");
const dns = require("node:dns");
(async () => {
  const s = http.createServer((q,r) => r.end("r1-guard-ok"));
  await new Promise((resolve) => s.listen(0, "0.0.0.0", resolve));
  const address = s.address();
  if (address.address !== "127.0.0.1") throw new Error("监听未限制为回环");
  const body = await (await fetch("http://127.0.0.1:" + address.port)).text();
  if (body !== "r1-guard-ok") throw new Error("本机响应被改变");
  let rejected = 0;
  try { await fetch("http://r1-guard-check.invalid/"); } catch (e) { if (e.code === "R1_LOCAL_ONLY_BLOCKED") rejected++; else throw e; }
  try { await fetch("http://127.0.0.1:18787/v1/chat/completions"); } catch (e) { if (e.code === "R1_LOCAL_ONLY_BLOCKED") rejected++; else throw e; }
  try { net.connect({host: "192.0.2.1", port: 80}); } catch (e) { if (e.code === "R1_LOCAL_ONLY_BLOCKED") rejected++; else throw e; }
  try { dns.lookup("r1-guard-check.invalid", () => {}); } catch (e) { if (e.code === "R1_LOCAL_ONLY_BLOCKED") rejected++; else throw e; }
  s.closeAllConnections();
  await new Promise((resolve) => s.close(resolve));
  if (rejected !== 4) throw new Error("拒绝分支未生效");
  console.log(JSON.stringify({loopback: true, responseUnchanged: true, blockedBeforeExternalIO: rejected}));
})().catch((e) => { console.error(e); process.exit(1); });
