// 本轮浏览器驱动：独立本机配置目录，命令通过标准输入串行执行。
const fs = require("node:fs");
const path = require("node:path");
const readline = require("node:readline");
const { chromium } = require("C:/Users/BAIBAI/AppData/Local/npm-cache/_npx/9833c18b2d85bc59/node_modules/playwright");
const root = __dirname;
const reportPath = path.join(root, "evidence", "browser-report.json");
const r = { root, network: [], console: [], errors: [], blocked: [], steps: {}, startedUtc: new Date().toISOString(), transport: "local-playwright-stdin", driverPid: process.pid };
const save = () => fs.writeFileSync(reportPath, JSON.stringify(r, (key,value) => ["context","page"].includes(key) ? undefined : value, 2) + "\n");
(async () => {
  const context = await chromium.launchPersistentContext(path.join(root, "browser-profile"), {
    executablePath: "C:/Program Files/Google/Chrome/Application/chrome.exe",
    headless: true, viewport: { width: 1440, height: 900 }, locale: "zh-CN",
    colorScheme: "light", serviceWorkers: "block",
    args: ["--no-proxy-server", "--disable-background-networking", "--disable-component-update", "--disable-sync", "--no-first-run", "--no-default-browser-check"]
  });
  const p = context.pages()[0] || await context.newPage();
  r.context = context; r.page = p;
  r.browserVersion = context.browser()?.version();
  p.setDefaultTimeout(60000);
  p.setDefaultNavigationTimeout(60000);
  await context.route("**/*", async route => {
    const u = new URL(route.request().url());
    if (["http:", "https:"].includes(u.protocol) && u.origin !== "http://127.0.0.1:3311") {
      r.blocked.push({ origin: u.origin, path: u.pathname });
      await route.abort("blockedbyclient");
    } else await route.continue();
  });
  p.on("response", res => {
    try { r.network.push({ time: new Date().toISOString(), path: new URL(res.url()).pathname, method: res.request().method(), status: res.status() }); } catch(e) { r.errors.push(String(e)); }
  });
  p.on("console", msg => { if (["error","warning"].includes(msg.type())) r.console.push({ type: msg.type(), text: msg.text() }); });
  p.on("pageerror", err => r.errors.push(String(err)));
  save();
  console.log(JSON.stringify({ ready: true, browserVersion: r.browserVersion, driverPid: process.pid }));
  const lines = readline.createInterface({ input: process.stdin, crlfDelay: Infinity });
  let chain = Promise.resolve();
  lines.on("line", line => {
    chain = chain.then(async () => {
      if (!line.trim()) return;
      const command = JSON.parse(line);
      if (command.close) {
        r.finishedUtc = new Date().toISOString(); save();
        await context.close();
        console.log(JSON.stringify({ id: command.id, closed: true }));
        process.exit(0);
      }
      try {
        const execute = new (Object.getPrototypeOf(async function(){}).constructor)("p", "r", "require", command.code);
        const value = await execute(p, r, require);
        save(); console.log(JSON.stringify({ id: command.id, result: value }));
      } catch (e) {
        save(); console.log(JSON.stringify({ id: command.id, error: String(e), stack: e.stack }));
      }
    }).catch(e => console.log(JSON.stringify({ driverError: String(e) })));
  });
})().catch(e => { console.error(e); process.exit(1); });
