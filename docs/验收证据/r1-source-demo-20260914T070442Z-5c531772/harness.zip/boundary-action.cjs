module.exports=async(p,r)=>{
 const fs=require("node:fs"); const path=require("node:path");
 const fixtures={zip:fs.readFileSync(path.join(r.root,"fixtures/r1-import.zip")).toString("base64"),png:fs.readFileSync(path.join(r.root,"fixtures/r1-upload.png")).toString("base64")};
 const results=await p.evaluate(async fixtures=>{
  const bytes=b64=>Uint8Array.from(atob(b64),c=>c.charCodeAt(0));
  const cfg=JSON.stringify({baseUrl:"http://127.0.0.1:18787/v1",apiKey:"r1-api-canary",model:"r1-api-canary"});
  const form=new FormData(); form.append("file",new Blob([bytes(fixtures.png)],{type:"image/png"}),"r1-upload.png");
  const cases=[
   ["llm-patch","/api/settings/llm","PATCH",cfg,{"Content-Type":"application/json"}],
   ["llm-delete","/api/settings/llm","DELETE"],
   ["tokens-list","/api/settings/tokens","GET"],
   ["tokens-create","/api/settings/tokens","POST",JSON.stringify({scope:"capture:write"}),{"Content-Type":"application/json"}],
   ["tokens-revoke","/api/settings/tokens?id=r1-absent-token","DELETE"],
   ["export","/api/export","GET"],
   ["backup","/api/backup","POST"],
   ["embedding-list","/api/embedding/backfill","GET"],
   ["embedding-start","/api/embedding/backfill","POST"],
   ["import","/api/import","POST",new Blob([bytes(fixtures.zip)],{type:"application/zip"}),{"Content-Type":"application/zip"}],
   ["llm-test","/api/llm/test","POST",cfg,{"Content-Type":"application/json"}],
   ["upload","/api/uploads","POST",form]
  ];
  const out=[];
  for(const [name,url,method,body,headers] of cases){
   const res=await fetch(url,{method,body,headers,credentials:"same-origin",signal:AbortSignal.timeout(8000)});
   const text=await res.text(); out.push({name,url,method,status:res.status,body:text.slice(0,200)});
   if(res.status!==403) break;
  }
  return out;
 },fixtures);
 r.steps.boundary={results,all403:results.length===12&&results.every(x=>x.status===403),zipBytes:Buffer.from(fixtures.zip,"base64").length,pngBytes:Buffer.from(fixtures.png,"base64").length};
 if(!r.steps.boundary.all403) throw new Error("受限入口未全部返回 403");
 return r.steps.boundary;
};
