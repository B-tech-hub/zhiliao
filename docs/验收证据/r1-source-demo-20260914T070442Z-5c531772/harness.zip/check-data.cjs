const fs=require("node:fs"), path=require("node:path");
const root=__dirname;
const Database=require(path.join(root,"candidate/node_modules/better-sqlite3"));
const db=new Database(path.join(root,"candidate/data-demo/db/app.db"),{readonly:true,fileMustExist:true});
const report=JSON.parse(fs.readFileSync(path.join(root,"evidence/browser-report.json"),"utf8"));
const entries=db.prepare("SELECT key,value FROM settings").all();
const pollution=[];
for(const prefix of ["llm","vision","image","reasoning","embedding"]){
 for(const [suffix,value] of [["base_url","http://127.0.0.1:18787/v1"],["api_key","r1-db-canary"],["model","r1-db-canary"]]){
  const key=prefix+"_"+suffix; pollution.push({key,preserved:entries.some(x=>x.key===key&&x.value===value)});
 }
}
const allMarkdown=[];
function walk(dir){if(!fs.existsSync(dir))return; for(const e of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,e.name);if(e.isDirectory())walk(p);else if(e.isFile()&&e.name.endsWith(".md"))allMarkdown.push(p);}}
walk(path.join(root,"candidate/data-demo/notes"));
const notes=[["cold",report.firstNoteId,report.firstContent],["restart",report.secondNoteId,report.secondContent]].map(([phase,id,expected])=>{
 const row=db.prepare("SELECT n.id,n.content,n.title,n.ai_status AS status,t.name AS topic FROM notes n JOIN topics t ON t.id=n.topic_id WHERE n.id=?").get(id);
 const paths=allMarkdown.filter(p=>path.basename(p).endsWith("-"+id+".md"));
 const body=paths.length===1?fs.readFileSync(paths[0],"utf8").replace(/^---\n[\s\S]*?\n---\n/,"").trim():null;
 return {phase,id,title:row.title,status:row.status,topic:row.topic,bodyPreserved:row.content===expected,markdownCount:paths.length,markdownBodyPreserved:body===expected.trim(),markdownPath:paths.length===1?path.relative(path.join(root,"candidate"),paths[0]).split(path.sep).join("/"):null};
});
const result={noteCount:db.prepare("SELECT COUNT(*) AS n FROM notes").get().n,pollutionKeys:pollution,notes,canaryDirectoryCreated:fs.existsSync(path.join(root,"candidate/canary")),formalDataDirectoryCreated:fs.existsSync(path.join(root,"candidate/data")),failedJobs:db.prepare("SELECT COUNT(*) AS n FROM ai_jobs WHERE status='failed'").get().n,timeUtc:new Date().toISOString()};
result.passed=pollution.every(x=>x.preserved)&&notes.every(n=>n.status==="done"&&n.topic==="羽毛球"&&n.bodyPreserved&&n.markdownCount===1&&n.markdownBodyPreserved)&&!result.canaryDirectoryCreated&&!result.formalDataDirectoryCreated&&result.failedJobs===0;
db.close();
fs.writeFileSync(path.join(root,"evidence/data-checks.json"),JSON.stringify(result,null,2)+"\n");
console.log(JSON.stringify(result));
if(!result.passed)process.exit(1);
