import hashlib,json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
marker=json.loads((root/"run-marker.json").read_text(encoding="utf-8-sig"))
source=Path(marker["source"])
before=json.loads((root/"preservation-before-private.json").read_text(encoding="utf-8"))
def sha(p):
 h=hashlib.sha256()
 with p.open("rb") as f:
  for block in iter(lambda:f.read(1024*1024),b""):h.update(block)
 return h.hexdigest()
current_paths=sorted(set(x.decode("utf-8") for x in subprocess.check_output(["git","ls-files","-z","--cached","--others","--exclude-standard"],cwd=source).split(b"\0") if x))
changed=[p for p,h in before["workspace"].items() if not (source/p).is_file() or sha(source/p)!=h]
added=[p for p in current_paths if p not in before["workspace"]]
protected_changed=[p for p,h in before["protectedHashes"].items() if not (source/p).is_file() or sha(source/p)!=h]
current_data={}
for directory in source.glob("data*"):
 if directory.is_dir():
  for p in directory.rglob("*"):
   if p.is_file():
    st=p.stat();current_data[p.relative_to(source).as_posix()]=[st.st_size,st.st_mtime_ns]
expected=json.loads((root/"evidence/candidate-manifest.json").read_text(encoding="utf-8"))
candidate_changes=[p for p,h in expected.items() if not (root/"candidate"/p).is_file() or sha(root/"candidate"/p)!=h]
result={"phase":"before-documents","workspaceFilesChecked":len(before["workspace"]),"workspaceChanged":changed,"workspaceAdded":added,"headUnchanged":subprocess.check_output(["git","rev-parse","HEAD"],cwd=source,text=True).strip()==before["head"],"indexUnchanged":sha(source/".git/index")==before["index"],"protectedHashFilesChecked":len(before["protectedHashes"]),"protectedHashChangedCount":len(protected_changed),"dataFilesChecked":len(before["dataMetadata"]),"dataMetadataUnchanged":current_data==before["dataMetadata"],"candidateRuntimeChanged":candidate_changes}
result["passed"]=not changed and not added and not protected_changed and result["dataMetadataUnchanged"] and result["headUnchanged"] and result["indexUnchanged"] and set(candidate_changes)<= {"tsconfig.json","next-env.d.ts"}
(root/"evidence/preservation-before-documents.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
print(json.dumps(result,ensure_ascii=False))
if not result["passed"]:raise SystemExit(1)
