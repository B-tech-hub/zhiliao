﻿param([Parameter(Mandatory=$true)][ValidateSet('cold','restart')][string]$Phase)
$ErrorActionPreference = 'Stop'
$r1Root = $PSScriptRoot
$r1Busy = @(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Where-Object { $_.LocalPort -in @(3311,8787,18787) })
if ($r1Busy.Count -gt 0) { throw '验收端口已被占用，不复用未知服务。' }
$env:R1_PHASE = $Phase
$r1Args = @('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File', ('"' + (Join-Path $r1Root 'run-demo.ps1') + '"'))
$r1Process = Start-Process -FilePath 'C:\WINDOWS\System32\WindowsPowerShell\v1.0\powershell.exe' -ArgumentList $r1Args -WorkingDirectory (Join-Path $r1Root 'candidate') -WindowStyle Hidden -RedirectStandardOutput (Join-Path $r1Root ('evidence\stdout-' + $Phase + '.log')) -RedirectStandardError (Join-Path $r1Root ('evidence\stderr-' + $Phase + '.log')) -PassThru
$r1Record = @{ pid = $r1Process.Id; startUtc = $r1Process.StartTime.ToUniversalTime().ToString('o'); phase = $Phase; command = 'npm.cmd run demo'; root = $r1Root }
[System.IO.File]::WriteAllText((Join-Path $r1Root ('process-' + $Phase + '.json')), ($r1Record | ConvertTo-Json), [System.Text.UTF8Encoding]::new($false))
$r1Record | ConvertTo-Json -Compress
$r1Watch = [System.Diagnostics.Stopwatch]::StartNew()
$r1Ready = $false
while ($r1Watch.Elapsed.TotalSeconds -lt 180) {
    $r1Process.Refresh()
    if ($r1Process.HasExited) { break }
    try {
        $r1Health = Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:3311/api/healthz' -TimeoutSec 3
        if ($r1Health.StatusCode -eq 200) { $r1Ready = $true; break }
    } catch {}
    Start-Sleep -Milliseconds 500
}
if (-not $r1Ready) {
    & (Join-Path $r1Root 'stop.ps1') -Phase $Phase
    throw '源码 Demo 未在 180 秒内健康，已停止本轮服务。'
}
$r1Listeners = @(Get-NetTCPConnection -State Listen | Where-Object { $_.LocalPort -in @(3311,8787) } | Select-Object LocalAddress,LocalPort,OwningProcess)
if ($r1Listeners.Count -ne 2 -or @($r1Listeners | Where-Object { $_.LocalAddress -ne '127.0.0.1' }).Count -gt 0) {
    & (Join-Path $r1Root 'stop.ps1') -Phase $Phase
    throw '本机监听保护未满足预期。'
}
$r1Result = @{ phase = $Phase; status = 200; elapsedSeconds = $r1Watch.Elapsed.TotalSeconds; health = ($r1Health.Content | ConvertFrom-Json); listeners = $r1Listeners; timeUtc = [DateTime]::UtcNow.ToString('o') }
[System.IO.File]::WriteAllText((Join-Path $r1Root ('evidence\startup-' + $Phase + '.json')), ($r1Result | ConvertTo-Json -Depth 8), [System.Text.UTF8Encoding]::new($false))
$r1Result | ConvertTo-Json -Depth 8 -Compress
