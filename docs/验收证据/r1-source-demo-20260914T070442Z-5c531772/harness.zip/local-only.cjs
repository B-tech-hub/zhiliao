// 本轮验收保护：只改变监听地址和网络许可，不改模型目标或响应。
const fs = require("node:fs");
const path = require("node:path");
const net = require("node:net");
const dns = require("node:dns");
const root = __dirname;
const phase = process.env.R1_PHASE || "unknown";
const logFile = path.join(root, "evidence", "network-" + phase + ".jsonl");
function log(event, fields = {}) {
  fs.appendFileSync(logFile, JSON.stringify({ time: new Date().toISOString(), pid: process.pid, ppid: process.ppid, event, ...fields }) + "\n");
}
const local = (host) => ["127.0.0.1", "localhost", "::1", "[::1]", "::ffff:127.0.0.1"].includes(String(host || "localhost").toLowerCase());
function deny(kind, host) {
  log("blocked", { kind, host: String(host) });
  const err = new Error("R1_LOCAL_ONLY_BLOCKED: " + kind + " " + host);
  err.code = "R1_LOCAL_ONLY_BLOCKED";
  throw err;
}
log("process", {
  entry: process.argv[1] ? path.basename(process.argv[1]) : "",
  cwd: process.cwd(),
  demoMode: process.env.DEMO_MODE,
  demoRuntime: process.env.DEMO_RUNTIME,
  passwordIsDemo: process.env.APP_PASSWORD === "demo",
  sessionIsDemo: process.env.SESSION_SECRET === "zhiliao-demo-session-secret-0123",
  databasePath: process.env.DATABASE_PATH,
  uploadDir: process.env.UPLOAD_DIR,
  notesDir: process.env.NOTES_EXPORT_DIR,
  llmBaseUrl: process.env.LLM_BASE_URL,
  llmKeyIsDemo: process.env.LLM_API_KEY === "demo",
  llmModel: process.env.LLM_MODEL
});
const originalListen = net.Server.prototype.listen;
net.Server.prototype.listen = function (...args) {
  let port;
  if (args[0] && typeof args[0] === "object" && !Array.isArray(args[0])) {
    if (args[0].port !== undefined) {
      port = args[0].port;
      args[0] = { ...args[0], host: "127.0.0.1" };
    }
  } else if (typeof args[0] === "number" || (typeof args[0] === "string" && /^\d+$/.test(args[0]))) {
    port = args[0];
    if (typeof args[1] === "string" || args[1] === undefined) args[1] = "127.0.0.1";
    else args.splice(1, 0, "127.0.0.1");
  }
  if (port !== undefined) {
    log("listen-request", { port: Number(port), host: "127.0.0.1" });
    this.once("listening", () => log("listening", { address: this.address() }));
  }
  return originalListen.apply(this, args);
};
const originalConnect = net.Socket.prototype.connect;
net.Socket.prototype.connect = function (...args) {
  const first = Array.isArray(args[0]) ? args[0][0] : args[0];
  if (first && typeof first === "object" && !first.path && first.port !== undefined) {
    if (!local(first.host)) deny("tcp", first.host);
  } else if (typeof first === "number" && typeof args[1] === "string" && !local(args[1])) {
    deny("tcp", args[1]);
  }
  return originalConnect.apply(this, args);
};
const originalLookup = dns.lookup;
dns.lookup = function (host, ...args) {
  if (host && !local(host)) deny("dns", host);
  return originalLookup.call(this, host, ...args);
};
const originalPromiseLookup = dns.promises.lookup;
dns.promises.lookup = async function (host, ...args) {
  if (host && !local(host)) deny("dns-promise", host);
  return originalPromiseLookup.call(this, host, ...args);
};
const originalFetch = globalThis.fetch;
if (originalFetch) {
  globalThis.fetch = async function (input, init) {
    const url = new URL(typeof input === "string" || input instanceof URL ? input : input.url);
    if (url.protocol === "http:" || url.protocol === "https:") {
      if (!local(url.hostname)) deny("fetch", url.hostname);
      const modelRequest = /\/(chat\/completions|embeddings|images\/(generations|edits))\/?$/.test(url.pathname);
      if (modelRequest && url.origin !== "http://127.0.0.1:8787") deny("model-target", url.origin);
      if (modelRequest) log("model-request", { origin: url.origin, path: url.pathname, method: init?.method || input?.method || "GET" });
    }
    const response = await originalFetch.call(this, input, init);
    if (url.hostname === "127.0.0.1" && url.port === "8787") log("model-response", { origin: url.origin, path: url.pathname, status: response.status });
    return response;
  };
}
