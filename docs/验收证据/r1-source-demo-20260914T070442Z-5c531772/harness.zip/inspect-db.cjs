const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const root = __dirname;
const Database = require(path.join(root, "candidate/node_modules/better-sqlite3"));
const dbPath = path.join(root, "candidate/data-demo/db/app.db");
const mode = process.argv[2] || "inspect";
const db = new Database(dbPath, { readonly: mode !== "pollute", fileMustExist: true });
const sha = value => crypto.createHash("sha256").update(value).digest("hex");
function files(dir) {
  const out = {};
  function walk(p) { if (!fs.existsSync(p)) return; for (const e of fs.readdirSync(p,{withFileTypes:true})) { const f=path.join(p,e.name); if(e.isDirectory()) walk(f); else if(e.isFile()) out[path.relative(dir,f).split(path.sep).join("/")] = sha(fs.readFileSync(f)); } }
  walk(dir); return out;
}
if (mode === "pollute") {
  const update = db.prepare("INSERT INTO settings (key,value,updated_at) VALUES (?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at");
  const keys = [];
  db.transaction(() => {
    for (const prefix of ["llm","vision","image","reasoning","embedding"]) {
      for (const [suffix,value] of [["base_url","http://127.0.0.1:18787/v1"],["api_key","r1-db-canary"],["model","r1-db-canary"]]) {
        const key = prefix + "_" + suffix; update.run(key,value,Date.now()); keys.push(key);
      }
    }
  })();
  const result = { keys, syntheticOnly:true, target:"http://127.0.0.1:18787/v1", inserted:keys.length, timeUtc:new Date().toISOString() };
  fs.writeFileSync(path.join(root,"evidence","db-pollution.json"),JSON.stringify(result,null,2)+"\n");
  console.log(JSON.stringify(result));
} else if (mode === "snapshot") {
  const label = process.argv[3];
  if (!/^[a-z0-9-]+$/.test(label || "")) throw new Error("快照名称无效");
  const tables = {};
  for (const table of db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").all()) {
    const rows = db.prepare('SELECT * FROM "'+table.name.replaceAll('"','""')+'"').all();
    const canonical = rows.map(row=>JSON.stringify(row)).sort();
    tables[table.name] = { count:rows.length, sha256:sha(JSON.stringify(canonical)) };
  }
  const dataFiles = files(path.join(root,"candidate/data-demo"));
  for (const key of Object.keys(dataFiles)) { if (key.startsWith("db/app.db")) delete dataFiles[key]; }
  const result = { tables, files:dataFiles, timeUtc:new Date().toISOString() };
  fs.writeFileSync(path.join(root,"evidence",label+".json"),JSON.stringify(result,null,2)+"\n");
  console.log(JSON.stringify({label, tables:Object.fromEntries(Object.entries(tables).map(([k,v])=>[k,v.count])), files:Object.keys(dataFiles).length}));
} else {
  const notes = db.prepare("SELECT n.id,n.title,n.content,n.ai_status AS aiStatus,n.summary,t.name AS topic FROM notes n JOIN topics t ON t.id=n.topic_id WHERE n.deleted_at IS NULL ORDER BY n.created_at DESC").all();
  const result = { noteCount:notes.length, states:db.prepare("SELECT ai_status AS status,COUNT(*) AS count FROM notes GROUP BY ai_status").all(), jobs:db.prepare("SELECT type,status,COUNT(*) AS count FROM ai_jobs GROUP BY type,status").all(), matches:notes.filter(n=>n.content.includes("R1验收")).map(n=>({...n,markdownFiles:Object.keys(files(path.join(root,"candidate/data-demo/notes"))).filter(f=>f.includes(n.id))})) };
  console.log(JSON.stringify(result));
}
db.close();
